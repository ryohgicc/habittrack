import './assets/index.ts-DE2tdWiu.js';
